/** Automatically generated file. DO NOT MODIFY */
package cp.obd.evdatautility;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}